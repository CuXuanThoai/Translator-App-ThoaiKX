# Translator-APP
# CuXuanThoai
# Translator App 
#### Video Demo:  https://youtu.be/yOG2Q8sQ-Kk
#### Description: A simple language translator app written in java, the application will translate the language according to the user's choice
